// P5JS setup
function setup() {
  createCanvas(600, 600);
  textFont('Indie Flower');
}

// P5JS draw
function draw() {
  noLoop(); // This is static sketch, so it doesn't need to be looped
  background(0); // Draw background
  Sign(); // Draw the name
  Title(); // Draw the name
  
  // Change anchor starting point to the center of the canvas
  translate(width/2, height/2); 
  
  // DRAWING PORTRAIT
  Hair();
  Skin();
  Fringe();
  Eyebrows();
  Eyes();
  Nose();
  Beard();
  Lips();
  // END OF THE DRAWING
}

// Draw skin, face
function Skin(){
  stroke(0);
  strokeWeight(0.2);
  fill(224, 172, 105); // Skin color
  rectMode(CENTER);
  ellipse(-150, -10, 20, 100, 20); // Left ear
  ellipse(150, -10, 20, 100, 20); // Right ear
  rect(0, 0, 300, 400, 200); // Face
}

// Draw nose
function Nose(){
  noStroke();
  fill(198, 134, 66); // Skin color (darker)
  triangle(-20, 50, 20, 50, 0, 0); // Nose
  
  stroke(198, 134, 66); // Skin color (darker)
  strokeWeight(15);
  point(-15, 43);
  point(15, 43);
}

// Draw eyes
function Eyes(){
  noStroke();
  fill(255); // Eyeball color
  ellipse(-60, -60, 50, 15) // Left eyeball
  ellipse(60, -60, 50, 15) // Right eyeball
  
  fill(0); // Eye color
  ellipse(-60, -60, 15, 10) // Left eye
  ellipse(60, -60, 15, 10) // Right eye
}

// Draw eyebrows
function Eyebrows(){
  stroke(245, 224, 119); // Hair color
  strokeWeight(8);
  line(-80, -80, -40, -75); // Left eyebrow
  line(80, -80, 40, -75); // Right eyebrow
}

// Draw long hair
function Hair(){
  fill(245, 224, 119); // Hair color
  strokeWeight(8);
  rectMode(CENTER);
  rect(0, -10, 400, 400, 200, 200, 0, 0); // Face
}

// Draw fringe
function Fringe(){
  stroke(245, 224, 119);
  strokeWeight(5);
  fill(245, 224, 119); // Hair color
  rectMode(CENTER);
  ellipse(0, -155, 220, 85);
}

// Draw lips
function Lips(){
  stroke(227,93,106); // Lips color
  strokeWeight(20);
  line(-30, 125, 30, 125); // Lips
}

// Draw beard
function Beard(){
  noStroke();
  fill(245, 224, 119); // Hair color
  rectMode(CENTER);
  rect(0, 150, 150, 150, 50, 50, 60, 60); // Beard
}

// Draw name
function Sign(){
  noStroke();
  fill(255);
  textAlign(LEFT, BOTTOM);
  textSize(40);
  text("Kevin Twiss", 10, height);
}

// Draw title
function Title(){
  noStroke();
  fill(255);
  textAlign(CENTER, TOP);
  textSize(30);
  text("Self Portrait", width/2, 50);
}