let nicknameInput1;
let nicknameInput2;
let button;
let requireLabel = null;

function Menu(){
  image(menuBackgroundImg, -width/2, 0, width*2, height); // BG
  
  domInfo();
  createForm();
  gameTitle();
}

function domInfo(){
  fill(255);    stroke(0);
  strokeWeight(5)
  textSize(60);
  textAlign(CENTER, CENTER);
  textFont(infoFont);
  text("Enter player nicknames !", width/2, height/4-textAscent());
}

function gameTitle(){
  noFill();
  stroke(0);
  strokeWeight(5);
  textSize(150);
  textAlign(CENTER, CENTER);
  textFont(titleFont);
  text("TAG GAME", width/2, height/2);
}

function createForm(){
  try{
  nicknameInput1 = createInput(players[0].nickname);
  } catch(err){
    nicknameInput1 = createInput('');
  }
  nicknameInput1.position(width/2-220, height/4);
  nicknameInput1.size(200);
  nicknameInput1.attribute("placeholder", "Player 1");
  nicknameInput1.attribute("maxlength", "8");
  
  try{
  nicknameInput2 = createInput(players[1].nickname);
  } catch(err){
    nicknameInput2 = createInput('');
  }
  nicknameInput2.position(width/2+20, height/4);
  nicknameInput2.size(200);
  nicknameInput2.attribute("placeholder", "Player 2");
  nicknameInput2.attribute("maxlength", "8");
  
  button = createButton('Start the game');
  button.position(width/2-75, height/4 + 30);
  button.size(150);
  button.mousePressed(buttonStart);
  
  requireInfo = createP('Both fields are required!');
  requireInfo.position(width/2-84, height/4-35);
  requireInfo.style('color', '#FF0000');
  requireInfo.style('font-weight', 'bold');
  requireInfo.size(168);
  requireInfo.hide();
}

function buttonStart(){
  if(nicknameInput1.value() != '' && nicknameInput2.value() != '')
    {
      nicknameInput1.remove();
      nicknameInput2.remove();
      button.remove();
      requireInfo.remove();
      
      started = true;
      players[0] = new Player(50, height - 0.03*(width+height),
                              nicknameInput1.value(), 0);
      players[1] = new Player(width-50, 0.03*(width+height),
                              nicknameInput2.value(), 1);
      players[Math.floor(Math.random()*2)].tagged = true;
      
    }
  else
    {
      requireInfo.show();
    }
}

