/* DYNAMIC SHAPES OBJECTS */

//X axis
const X1 = {x: 10, y: 300, r: 10, speed: 1, dir: 1, col: 0};
const X2 = {x: 590, y: 300, r: 10, speed: 2, dir: -1, col: 0};

//Y axis
const Y1 = {x: 300, y: 10, r: 10, speed: 4, dir: 1, col: 0};
const Y2 = {x: 300, y: 590, r: 10, speed: 3, dir: -1, col: 0};

//Diagonal
const XY1 = {x: 0, y: 600, w: 30, h: 10, speed: 1.5, dir: -1, col: 0};

//Dynamic title size and size controller
var sz = 30, a = 0.1;

//Dynamic face scale and scale controller
var scl = 0.8, b = 0.002;

// P5JS setup
function setup() {
  createCanvas(600, 600);
  textFont('Indie Flower');
  
  X1.col = color(random(0,256), random(0,256), random(0,256));
  X2.col = color(random(0,256), random(0,256), random(0,256));
  Y1.col = color(random(0,256), random(0,256), random(0,256));
  Y2.col = color(random(0,256), random(0,256), random(0,256));
  XY1.col = color(random(0,256), random(0,256), random(0,256));
}

// P5JS draw
function draw() {
  background(0); // Draw background
  Sign(); // Draw the name
  Title(); // Draw the title
  
  push();
  // Change anchor starting point to the center of the canvas
  translate(width/2, height/2); 
  // Change the scale of the drawing continuosly
  if(scl > 1) b = -0.002;
  else if(scl < 0.8) b = 0.002;
  scl+=b;
  scale(scl);
  
  // DRAWING PORTRAIT
  Hair();
  Skin();
  Fringe();
  Eyebrows();
  Eyes();
  Nose();
  Beard();
  Lips();
  // END OF THE DRAWING
  pop();
  
  push();
  // DRAWING OTHER SHAPES
  ShapeOnX();
  ShapeOnY();
  ShapeOnXY();
  // END OF THE DRAWING
  pop();
  
}


/* DRAWING ADDITIONAL SHAPES FUNCTIONS */
// Drawing rects along the x axis, they go back and fourth
function ShapeOnX(){
  noStroke();
  fill(X1.col);
  rect(X1.x, X1.y, X1.r);
  
  fill(X2.col);
  rect(X2.x, X2.y, X2.r);
  
  if(X1.x > 590){
    X1.dir = -1;
  }else if(X1.x < 10){
    X1.dir = 1;
    X1.col = color(random(0,256), random(0,256), random(0,256));
  }
  X1.x+=X1.speed*X1.dir;
  
  if(X2.x > 590){
    X2.dir = -1;
    X2.col = color(random(0,256), random(0,256), random(0,256));
  }else if(X2.x < 10){
    X2.dir = 1;
    X2.col = color(random(0,256), random(0,256), random(0,256));
  }
  X2.x+=X2.speed*X2.dir;
}

// Drawing circles along the y axis, they go back and fourth
function ShapeOnY(){
  noStroke();
  fill(Y1.col);
  circle(Y1.x, Y1.y, Y1.r);
  
  fill(Y2.col);
  circle(Y2.x, Y2.y, Y2.r);
  
  if(Y1.y > 590){
    Y1.dir = -1;
    Y1.col = color(random(0,256), random(0,256), random(0,256));
  }else if(Y1.y < 10){
    Y1.dir = 1;
    Y1.col = color(random(0,256), random(0,256), random(0,256));
  }
  Y1.y+=Y1.speed*Y1.dir;
  
  if(Y2.y > 590){
    Y2.dir = -1;
    Y2.col = color(random(0,256), random(0,256), random(0,256));
  }else if(Y2.y < 10){
    Y2.dir = 1;
    Y2.col = color(random(0,256), random(0,256), random(0,256));
  }
  Y2.y+=Y2.speed*Y2.dir;
}

// Drawing ellipse diagonally, it goes back and fourth
function ShapeOnXY(){
  noStroke();
  fill(XY1.col);
  ellipse(XY1.x, XY1.y, XY1.w, XY1.h);
  if(XY1.x <= 0){
    XY1.dir = -1;
    XY1.col = color(random(0,256), random(0,256), random(0,256));
  }else if(XY1.x >= 600){
    XY1.dir = 1;
    XY1.col = color(random(0,256), random(0,256), random(0,256)); 
  }
  XY1.x-=XY1.speed*XY1.dir;
  XY1.y+=XY1.speed*XY1.dir;
}

/* DRAWING PORTRAIT FUNCTIONS */
// Draw skin, face
function Skin(){
  stroke(0);
  strokeWeight(0.2);
  fill(224, 172, 105); // Skin color
  rectMode(CENTER);
  ellipse(-150, -10, 20, 100, 20); // Left ear
  ellipse(150, -10, 20, 100, 20); // Right ear
  rect(0, 0, 300, 400, 200); // Face
}

// Draw nose
function Nose(){
  noStroke();
  fill(198, 134, 66); // Skin color (darker)
  triangle(-20, 50, 20, 50, 0, 0); // Nose
  
  stroke(198, 134, 66); // Skin color (darker)
  strokeWeight(15);
  point(-15, 43);
  point(15, 43);
}

// Draw eyes
function Eyes(){
  noStroke();
  fill(255); // Eyeball color
  ellipse(-60, -60, 50, 15) // Left eyeball
  ellipse(60, -60, 50, 15) // Right eyeball
  
  fill(0); // Eye color
  ellipse(-60, -60, 15, 10) // Left eye
  ellipse(60, -60, 15, 10) // Right eye
}

// Draw eyebrows
function Eyebrows(){
  stroke(245, 224, 119); // Hair color
  strokeWeight(8);
  line(-80, -80, -40, -75); // Left eyebrow
  line(80, -80, 40, -75); // Right eyebrow
}

// Draw long hair
function Hair(){
  fill(245, 224, 119); // Hair color
  strokeWeight(8);
  rectMode(CENTER);
  rect(0, -10, 400, 400, 200, 200, 0, 0); // Face
}

// Draw fringe
function Fringe(){
  stroke(245, 224, 119);
  strokeWeight(5);
  fill(245, 224, 119); // Hair color
  rectMode(CENTER);
  ellipse(0, -155, 220, 85);
}

// Draw lips
function Lips(){
  stroke(227,93,106); // Lips color
  strokeWeight(20);
  line(-30, 125, 30, 125); // Lips
}

// Draw beard
function Beard(){
  noStroke();
  fill(245, 224, 119); // Hair color
  rectMode(CENTER);
  rect(0, 150, 150, 150, 50, 50, 60, 60); // Beard
}

// Draw name
function Sign(){
  noStroke();
  fill(255);
  textAlign(LEFT, BOTTOM);
  textSize(40);
  text("Kevin Twiss", 10, height);
}

// Draw dynamic title
function Title(){
  if(sz > 35) a = -0.1;
  else if(sz < 30) a = 0.1;
  sz+=a;
  noStroke();
  fill(255);
  textAlign(CENTER, TOP);
  textSize(sz);
  text("Self Portrait", width/2, textAscent());
}
